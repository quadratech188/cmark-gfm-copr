<div class="this is an html block">

blah blah

</div>

<table>
  <tr>
    <td>
      **test**
    </td>
  </tr>
</table>

<table>

  <tr>

    <td>

      test

    </td>

  </tr>

</table>

<![CDATA[
  [[[[[[[[[[[... *cdata section - this should not be parsed* ...]]]]]]]]]]]
]]>

